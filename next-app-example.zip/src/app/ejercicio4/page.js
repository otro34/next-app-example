'use client';

const Ejercicio3 = () => {

    return (
        <div>
            <h2>
            Ejercicio 4
            </h2>
            <p>
                Crear un componente compartido. El componente deberá renderizar un chip. 
                Usar el chip para renderizar el contenido de la lista.   
            </p>
        </div>
    )
} 

export default Ejercicio3