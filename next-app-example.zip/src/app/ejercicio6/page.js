'use client';

const Ejercicio6 = () => {
    return (
        <div>
            <h2>
            Ejercicio 6
            </h2>
            <p>
                Agregar un TopBar.
                Agregar un Menu.
                Agregar una sección pricipal con un artículo.
                Agregar un botón que al hacer click muestre un modal. 
            </p>
        </div>
    )
} 

export default Ejercicio6